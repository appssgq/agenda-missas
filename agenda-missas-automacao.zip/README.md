# Agenda de Missas - Automação

Worker para Railway.

- Consulta a tabela `missas` no Supabase.
- Às 09:00 no fuso `America/Sao_Paulo`, procura missas que acontecerão em 5, 3 ou 1 dia.
- Envia o lembrete pelo Evolution API para o grupo configurado.
- Registra em `lembretes_missas` para evitar duplicidade.

## Variáveis no Railway

- SUPABASE_URL
- SUPABASE_SERVICE_KEY
- EVOLUTION_URL
- EVOLUTION_API_KEY
- EVOLUTION_INSTANCE
- GROUP_JID
- TIMEZONE
